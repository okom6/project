#!/usr/bin/env python
#encoding: utf-8

napis1="Ala.ma.kota"

print napis1.split(".")
