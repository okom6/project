#!/usr/bin/env python
#encoding: utf-8

with open("plik.txt") as f:
	print f.read()




#f=open("plik.txt")
#for x in f:
#	print x
#
#f.close()




#f=open("plik.txt")
#print f.read()
#f.close()
