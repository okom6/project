#!/usr/bin/env python
#encoding: utf-8

with open("plik.txt","w") as f:
	f.write("test1")
	f.write("test2")
