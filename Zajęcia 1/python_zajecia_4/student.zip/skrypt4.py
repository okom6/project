#!/usr/bin/env python
#encoding: utf-8

lista=["a","b","c","d"]
napis=''

print "".join(lista)



#for x in lista:
#	napis=napis+x

#print napis



#napis='''test1
#test2'''
#print napis
